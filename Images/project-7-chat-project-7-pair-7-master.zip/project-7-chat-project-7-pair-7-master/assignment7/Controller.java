package assignment7;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class Controller {
    private BufferedReader reader;
    private PrintWriter writer;
    HashMap<String,ArrayList<String>> convos = new HashMap<>();
    @FXML
    private Button nameButton,createGCButton,exitButton,resetButton,sendButton,setServer,addFriend;
    @FXML
    private Label nameTitle;
    @FXML
    private TextArea messageHist;
    @FXML
    private TextField messageInput,nameInput;
    @FXML
    private ComboBox cBox;
    @FXML
    private void initialize(){
        //Make sure to create with according name
        nameTitle.setText("Login to Start a Conversation!");
        //Populate ComboBox
        cBox.getItems().addAll("","Broadcast");
        //Sending a Message with Button or Enter
        messageInput.setOnAction(this::sendMessage);
        nameButton.setOnAction(this::setNameButton);
        sendButton.setOnAction(this::sendMessage);
        createGCButton.setOnAction(this::setGroupChatButton);
        cBox.setOnAction(this::setcBox);

        //Utility Functions
        setServer.setOnAction(this::setNewServer);
        exitButton.setOnAction(this::setExitButton);
        resetButton.setOnAction(this::setResetButton);
        addFriend.setOnAction(this::setAddFriendButton);
        //set networking up on client
        try {setUpNetworking("127.0.0.1");
        }catch (Exception e) {e.printStackTrace();}
    }

    @FXML
    private void setNameButton(ActionEvent event){
        nameTitle.setText(nameInput.getText());
        writer.println("setName:" + nameInput.getText());
        writer.flush();
        nameInput.setText("");
    }
    @FXML
    private void setcBox(Event event){
        messageHist.clear();
        String conv = (String) cBox.getValue();
        for(int i=0;i<convos.get(conv).size();i++){
            messageHist.appendText(convos.get(conv).get(i)+"\n");
        }
    }
    @FXML
    private void setGroupChatButton(ActionEvent event) {
        writer.println("createGC:" + nameInput.getText());
        writer.flush();
        String[] user = nameInput.getText().split(":");
        cBox.getItems().add(user[0]);
        convos.put(user[0],new ArrayList<>());
        nameInput.setText("");
    }
    @FXML
    private void setExitButton(ActionEvent event){System.exit(0);}
    @FXML
    private void setResetButton(ActionEvent event){messageHist.clear();}
    @FXML
    private void setAddFriendButton(ActionEvent event){cBox.getItems().add(nameInput.getText());}
    @FXML
    private void sendMessage(ActionEvent event){
        writer.println(cBox.getValue() +":"+ messageInput.getText());
        writer.flush();
        messageInput.setText("");
        messageInput.requestFocus();
    }

    private void setUpNetworking(String addy) throws Exception {
        @SuppressWarnings("resource")
        Socket sock = new Socket(addy, 4242);
        InputStreamReader streamReader = new InputStreamReader(sock.getInputStream());
        reader = new BufferedReader(streamReader);
        writer = new PrintWriter(sock.getOutputStream());
        System.out.println("networking established");
        Thread readerThread = new Thread(new IncomingReader());
        readerThread.start();
    }
    @FXML
    private void setNewServer(ActionEvent event){
        try {setUpNetworking(nameInput.getText());
        }catch (Exception e) {}
    }
    class IncomingReader implements Runnable {
        @FXML
        public void run() {
            String message;
            try {while ((message = reader.readLine()) != null) {
                String[] inMSG= message.split(":");
                try{convos.get(inMSG[0]).add(inMSG[1]);
                }catch(Exception e){
                    convos.put(inMSG[0], new ArrayList<>());
                    convos.get(inMSG[0]).add(inMSG[1]);
                    if(!cBox.getItems().contains(inMSG[0]))
                    cBox.getItems().add(inMSG[0]);
                }
                messageHist.clear();
                for(int i=0;i<convos.get(inMSG[0]).size();i++){
                    messageHist.appendText(convos.get(inMSG[0]).get(i)+"\n");
                }
            }} catch (IOException ex) {}
        }
    }
}
