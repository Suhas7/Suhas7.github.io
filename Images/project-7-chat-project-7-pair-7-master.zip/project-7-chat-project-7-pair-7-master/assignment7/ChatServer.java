package assignment7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class ChatServer {
    private ArrayList<PrintWriter> clientOutputStreams;
    private HashMap<String, PrintWriter> clients;
    private HashMap<String, ArrayList<PrintWriter>> groupChats;
    private int uniqueId;

    public static void main(String[] args) {
        try {
        		new ChatServer().setUpNetworking();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpNetworking() throws Exception {
        clientOutputStreams = new ArrayList<PrintWriter>();
        clients = new HashMap<String, PrintWriter>();
        groupChats = new HashMap<String, ArrayList<PrintWriter>>();
        uniqueId = 0;
        @SuppressWarnings("resource")
        ServerSocket serverSock = new ServerSocket(4242);
        while (true) {
            Socket clientSocket = serverSock.accept();
            PrintWriter writer = new PrintWriter(clientSocket.getOutputStream());
            uniqueId++;
            clientOutputStreams.add(writer);
            clients.put("User " + uniqueId, writer);
            Thread t = new Thread(new ClientHandler(clientSocket, uniqueId));
            t.start();
            System.out.println("got a connection");
        }

    }

    private void notifyClients(String message, String id) {
        String[] user = message.split(":");
        if (user[0].equals("Broadcast")) {
            for (String s : clients.keySet()) {
                PrintWriter writer = clients.get(s);
                writer.println("Broadcast:"+id + "-" + user[1]);
                writer.flush();
            }
        } else if (groupChats.containsKey(user[0])) {
            ArrayList<PrintWriter> sendingClients = groupChats.get(user[0]);
            PrintWriter sendingClient = clients.get(id);
            System.out.println("The recipient group chat is " + user[0]);
            for (PrintWriter writer : sendingClients) {
                writer.println(user[0]+":"+id+"- "+user[1]);
                writer.flush();
            }
        } else {
            PrintWriter receivingClient = clients.get(user[0]);
            PrintWriter sendingClient = clients.get(id);
            receivingClient.println(id+":"+id+"- "+user[1]);
            receivingClient.flush();
            sendingClient.println(user[0]+":"+user[0]+"- "+user[1]);
            sendingClient.flush();
        }
    }

    class ClientHandler implements Runnable {
        private BufferedReader reader;
        public String id;
        public ClientHandler(Socket clientSocket, int uid) throws IOException {
        		id = "User " + uid;
            Socket sock = clientSocket;
            reader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
        }

        public void run() {
            String message;
            try {
                while ((message = reader.readLine()) != null) {
                    System.out.println("read " + message);
                    ArrayList<PrintWriter> pws;
                    String[] messageComponents = message.split(":");
                    if (messageComponents[0].equals("setName")) {
                    		System.out.println("changing the name");
                    		PrintWriter w = clients.get(id);
                    		clients.remove(id);
                    		id = messageComponents[1];
                    		clients.put(id, w);
                    } else if (messageComponents[0].equals("createGC")) {
                    		System.out.println("Creating a group chat");
                    		String[] usrs = messageComponents[2].split(",");
                    		pws = new ArrayList<PrintWriter>();
                    		for (String u : usrs) {
                    			pws.add(clients.get(u));
                    		}
                    		System.out.println("The group chat name is " + messageComponents[1]);
                    		groupChats.put(messageComponents[1], pws);
                    } else {
                    		notifyClients(message, id);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
