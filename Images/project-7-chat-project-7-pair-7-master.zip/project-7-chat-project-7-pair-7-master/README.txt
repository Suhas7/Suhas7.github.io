Suhas Raja- scr2469
Balakumaran Balasubramanian- bb83775
https://github.com/EE422C-Fall-2018/project-7-chat-project-7-pair-7.git

We are submitting ChatServer.java, Controller.java, and Main.java. The first file contains the server code, and the latter two define client behavior.
These files are packaged into Server.jar and Client.jar.

We tested the code on a windows machine, by sending different messages between clients through the broadcast, individual, and group channels.